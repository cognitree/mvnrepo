# Kronos

[![Build Status](https://api.travis-ci.com/cognitree/kronos.svg)](https://travis-ci.com/cognitree/kronos/builds)

Kronos is a java based replacement for cron to build, run and monitor complex data pipelines with flexible deployment options. Please view the wiki for usage, information, getting started etc https://github.com/cognitree/kronos/wiki

# Contribute

- Source Code: https://github.com/cognitree/kronos
- Issue Tracker: https://github.com/cognitree/kronos/issues

Please forward your comments and feature requests to oss@cognitree.com

# License

The project is licensed under the Apache 2 license.
