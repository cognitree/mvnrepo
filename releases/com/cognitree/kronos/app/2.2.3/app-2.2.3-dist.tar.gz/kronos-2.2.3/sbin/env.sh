#!/bin/bash

export HOST="localhost"
export PORT=8080
export HEAP_OPTS="-Xmx128m -Xms128m"